<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "books";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $studentName = $_POST['studentName'];
    $studentId = $_POST['studentId'];
    $bookTitle = $_POST['bookTitle'];
    $borrowDate = $_POST['borrowDate'];
    $returnDate = $_POST['returnDate'];
    $token = $_POST['token'];
    $fees = $_POST['fees'];
    $paid = $_POST['paid'];

    // Load JSON data
    $jsonData = file_get_contents('token.json');
    $data = json_decode($jsonData, true);

    // Check if the token is valid (exists in unused tokens)
    if (in_array($token, $data['tokens'])) {
        // Token is valid, move it to used tokens
        $data['tokens'] = array_diff($data['tokens'], [$token]);
        $data['used_tokens'][] = $token;

        // Save the updated token data to the JSON file
        file_put_contents('token.json', json_encode($data, JSON_PRETTY_PRINT));

        // Insert the borrow details into the database
        // Corrected SQL query
$sql = "INSERT INTO borrowed_books (student_name, student_id, book_title, borrow_date, return_date, token, fees, paid)
VALUES ('$studentName', '$studentId', '$bookTitle', '$borrowDate', '$returnDate', '$token', '$fees', '$paid')";


        if ($conn->query($sql) === TRUE) {
            echo "Borrow record added successfully.";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        // Token is invalid
        echo "Invalid or already used token.";
    }
}

// Close the connection
$conn->close();
?>
