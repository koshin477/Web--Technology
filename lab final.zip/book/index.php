<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Shape</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="img">
        <img src="img.jpg" height="500px" width="1000px">
    </div>

    <div class="container">
        <div class="rectangle">
            <h2>Borrowed Books List</h2>
            <table>
                <thead>
                    <tr>
                        <th>Student Name</th>
                        <th>Student ID</th>
                        <th>Book Title</th>
                        <th>Borrow Date</th>
                        <th>Return Date</th>
                        <th>Token</th>
                        <th>Fees</th>
                        <th>Paid</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Database connection
                    $servername = "localhost";
                    $username = "root";
                    $password = "";
                    $dbname = "books";

                    // Create connection
                    $conn = new mysqli($servername, $username, $password, $dbname);

                    // Check connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    // Fetch borrowed books from the database
                    $sql = "SELECT student_name, student_id, book_title, borrow_date, return_date, token, fees, paid FROM borrowed_books";
                    $result = $conn->query($sql);

                    // Display the borrowed books in a table
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row['student_name']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['student_id']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['book_title']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['borrow_date']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['return_date']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['token']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['fees']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['paid']) . "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='8'>No borrowed books found in the database.</td></tr>";
                    }

                    // Close the connection
                    $conn->close();
                    ?>
                </tbody>
            </table>
        </div>

        <div class="rectangle">
            <h2>Manage Books</h2>
            <table>
                <thead>
                    <tr>
                        <th>Book Title</th>
                        <th>Author</th>
                        <th>ISBN</th>
                        <th>Copy Count</th>
                        <th>Category</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Database connection
                    $servername = "localhost";
                    $username = "root";
                    $password = "";
                    $dbname = "books";

                    // Create connection
                    $conn = new mysqli($servername, $username, $password, $dbname);

                    // Check connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    // Fetch books from the database
                    $sql = "SELECT * FROM books";
                    $result = $conn->query($sql);

                    // Display the book list with update and delete options
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row['BookTitle']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['Author']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['ISBN']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['Copy_count']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['Category']) . "</td>";
                            echo "<td>";
                            echo "<a href='update.php?title=" . urlencode($row['BookTitle']) . "'>Update</a> | ";
                            echo "<a href='delete.php?title=" . urlencode($row['BookTitle']) . "' onclick=\"return confirm('Are you sure you want to delete this book?');\">Delete</a>";
                            echo "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='6'>No books found in the database.</td></tr>";
                    }

                    // Close the connection
                    $conn->close();
                    ?>
                </tbody>
            </table>
        </div>

        <!-- Token Container (Unused & Used Tokens) -->
        <div class="token-container">
            <!-- Unused Tokens -->
            <div class="unused-tokens">
                <h3>Unused Tokens</h3>
                <?php
                // Load JSON data
                $jsonData = file_get_contents('token.json');
                $data = json_decode($jsonData, true);

                // Display unused tokens
                if (isset($data['tokens']) && count($data['tokens']) > 0) {
                    echo '<ul>';
                    foreach ($data['tokens'] as $token) {
                        echo '<li>' . htmlspecialchars($token) . '</li>';
                    }
                    echo '</ul>';
                } else {
                    echo '<p>No unused tokens available</p>';
                }
                ?>
            </div>

            <!-- Used Tokens -->
            <div class="used-tokens">
                <h3>Used Tokens</h3>
                <?php
                // Display used tokens
                if (isset($data['used_tokens']) && count($data['used_tokens']) > 0) {
                    echo '<ul>';
                    foreach ($data['used_tokens'] as $token) {
                        echo '<li>' . htmlspecialchars($token) . '</li>';
                    }
                    echo '</ul>';
                } else {
                    echo '<p>No used tokens available</p>';
                }
                ?>
            </div>
        </div>

        <!-- Square Container (Images) -->
        <div class="square-container">
            <div class="square"><img src="image.png" height="200px" width="300px"></div>
            <div class="square"><img src="image2.png" height="200px" width="300px"></div>
            <div class="square"><img src="image3.png" height="200px" width="300px"></div>
        </div>

        <!-- Box Container for Forms -->
        <div class="box-container">
            <!-- Borrow Form -->
            <div class="box1">
                <div class="form-container">
                    <h2>Borrow Form</h2>
                    <form action="process.php" method="POST">
                        <label for="studentName">Student Name:</label>
                        <input type="text" id="studentName" name="studentName" required>

                        <label for="studentId">Student ID:</label>
                        <input type="text" id="studentId" name="studentId" required>

                        <label for="bookTitle">Book Title:</label>
                        <select id="bookTitle" name="bookTitle" required>
                            <?php
                            $servername = "localhost";
                            $username = "root";
                            $password = "";
                            $dbname = "books";

                            // Create connection
                            $conn = new mysqli($servername, $username, $password, $dbname);

                            // Check connection
                            if ($conn->connect_error) {
                                die("Connection failed: " . $conn->connect_error);
                            }

                            // Fetch book titles from the database
                            $sql = "SELECT BookTitle FROM books";
                            $result = $conn->query($sql);

                            // Check if there are any books
                            if ($result->num_rows > 0) {
                                // Output data for each book
                                while ($row = $result->fetch_assoc()) {
                                    echo "<option value='" . $row["BookTitle"] . "'>" . $row["BookTitle"] . "</option>";
                                }
                            } else {
                                echo "<option>No books available</option>";
                            }

                            // Close connection
                            $conn->close();
                            ?>
                        </select>

                        <label for="borrowDate">Borrow Date:</label>
                        <input type="date" id="borrowDate" name="borrowDate" required>

                        <label for="token">Token:</label>
                        <input type="text" id="token" name="token" required>

                        <label for="returnDate">Return Date:</label>
                        <input type="date" id="returnDate" name="returnDate" required>

                        <label for="fees">Fees:</label>
                        <input type="number" id="fees" name="fees" required>

                        <label for="paid">Paid:</label>
                        <select id="paid" name="paid" required>
                            <option value="yes">Yes</option>
                            <option value="no">No</option>
                        </select>

                        <button type="submit">Submit</button>
                    </form>
                </div>
            </div>

            <!-- Book Form -->
            <div class="box2">
                <div class="form-container">
                    <h2>Book Form</h2>
                    <form action="submit.php" method="POST">
                        <label for="bookTitle">Book Title:</label>
                        <input type="text" id="bookTitle" name="bookTitle" required>

                        <label for="author">Author:</label>
                        <input type="text" id="author" name="author" required>

                        <label for="isbn_no">ISBN No:</label>
                        <input type="text" id="isbn_no" name="isbn_no" required>

                        <label for="copyCount">Copy Count:</label>
                        <input type="number" id="copyCount" name="copyCount" required>

                        <label for="category">Category:</label>
                        <input type="text" id="category" name="category" required>

                        <button type="submit">Submit</button>
                    </form>
                </div>
            </div>
        </div>

    </div>
</body>
</html>