<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "books";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $bookTitle = $_POST['bookTitle'];
    $author = $_POST['author'];
    $isbnNo = $_POST['isbn_no'];
    $copyCount = $_POST['copyCount'];
    $category = $_POST['category'];

    // Insert the new book into the database
    $sql = "INSERT INTO books (BookTitle, Author, ISBN, Copy_count, Category)
            VALUES ('$bookTitle', '$author', '$isbnNo', '$copyCount', '$category')";

    if ($conn->query($sql) === TRUE) {
        // Successful insertion, show a success message and redirect to the previous page
        echo "<script>
                alert('New book added successfully.');
                window.history.back(); // Go back to the previous page
              </script>";
    } else {
        // Show an error if something went wrong
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the connection
$conn->close();
?>
