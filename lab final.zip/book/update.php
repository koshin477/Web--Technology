<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "books";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the book title from the query parameter
if (isset($_GET['title'])) {
    $bookTitle = urldecode($_GET['title']);
    
    // Fetch the book details
    $sql = "SELECT * FROM books WHERE BookTitle = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $bookTitle);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $book = $result->fetch_assoc();
    } else {
        echo "Book not found.";
        exit;
    }
} else {
    echo "No book selected.";
    exit;
}

// Update the book details
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $updatedTitle = $_POST['bookTitle'];
    $author = $_POST['author'];
    $isbn = $_POST['isbn'];
    $copyCount = $_POST['copyCount'];
    $category = $_POST['category'];

    $updateSql = "UPDATE books SET BookTitle = ?, Author = ?, ISBN = ?, Copy_count = ?, Category = ? WHERE BookTitle = ?";
    $updateStmt = $conn->prepare($updateSql);
    $updateStmt->bind_param("sssiss", $updatedTitle, $author, $isbn, $copyCount, $category, $bookTitle);

    if ($updateStmt->execute()) {
        echo "Book updated successfully!";
        header("Location: index.php"); // Redirect to the main page
        exit;
    } else {
        echo "Error updating book: " . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Book</title>
</head>
<body>
    <h2>Update Book</h2>
    <form action="" method="POST">
        <label for="bookTitle">Book Title:</label>
        <input type="text" id="bookTitle" name="bookTitle" value="<?php echo htmlspecialchars($book['BookTitle']); ?>" required><br>

        <label for="author">Author:</label>
        <input type="text" id="author" name="author" value="<?php echo htmlspecialchars($book['Author']); ?>" required><br>

        <label for="isbn">ISBN:</label>
        <input type="text" id="isbn" name="isbn" value="<?php echo htmlspecialchars($book['ISBN']); ?>" required><br>

        <label for="copyCount">Copy Count:</label>
        <input type="number" id="copyCount" name="copyCount" value="<?php echo htmlspecialchars($book['Copy_count']); ?>" required><br>

        <label for="category">Category:</label>
        <input type="text" id="category" name="category" value="<?php echo htmlspecialchars($book['Category']); ?>" required><br>

        <button type="submit">Update</button>
    </form>
</body>
</html>
